function r = calculated_distances(x)
r = [(x(3)-x(1))^2 + (x(4)-x(2))^2; (x(5)-x(1))^2 + (x(6)-x(2))^2; (x(7)-x(1))^2 + (x(8)-x(2))^2; 0; 0];
end
